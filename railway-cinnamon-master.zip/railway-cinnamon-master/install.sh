#!/bin/bash
cd Railway/cinnamon/
./utils.sh --install
